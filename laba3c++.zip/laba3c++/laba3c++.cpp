﻿#include <iostream>
using namespace std;
int main()
{
	int i;
	int chislo = 13;
	unsigned short int arr[] = { 300,5000,1269,983,555 };
	for (int i = 0; i < 5; i++) {
		arr[i] += chislo;
		cout << "arr[" << i << "] = " << arr[i] << endl;
	}
}